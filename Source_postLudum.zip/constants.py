#Colors:
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (0, 255, 255)
#ColorKey:
COLORKEY = (255, 0, 255)

#Music Settings:
music_volume = 0.1
effect_volume = 0.5

#Display Settings:
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
ISFULLSCREEN = False

#Menu Settings:
ISINTRO = True

MULTIPLAYER = False
SERVER = False
IP = "127.0.0.1"
PORT = 5000
